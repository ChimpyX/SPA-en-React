

export const Card = () => {
  return (
    <div>Card</div>
  )
}
