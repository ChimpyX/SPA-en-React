import { HeroeList } from "../components/HeroeList"


export const ComicPage = () => {
  return (
    <>
      <HeroeList tipo="comics"/>
    </>
  )
}
