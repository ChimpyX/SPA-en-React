import { HeroeList } from "../components/HeroeList"


export const AnimePage = () => {
  return (
    <>
      <HeroeList tipo="anime"/>
    </>
  ) 
}
