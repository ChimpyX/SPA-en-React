import { AppRouter } from "./router/AppRouter"


export const HeroesApp = () => {
  return (
    <>
      <AppRouter/>
    </>
  )
}
